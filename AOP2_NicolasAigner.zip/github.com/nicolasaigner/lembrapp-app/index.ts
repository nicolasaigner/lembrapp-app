// Para compatibilidade com Snack.expo.dev
import App from './App';

export default App;
