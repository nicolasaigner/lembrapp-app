import { colors } from "./colors";

export const lightTheme = {
  mode: "light" as const,
  colors: colors.light,
};
